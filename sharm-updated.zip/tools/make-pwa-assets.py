#!/usr/bin/env python3
"""Regenerates every PWA / splash image from ONE source logo (tools/pwa-src/logo.png, transparent PNG).
   python3 tools/make-pwa-assets.py      (needs Pillow)
Writes into shared/pwa/: icons (any + maskable), apple-touch-icon, splash-logo.png (the in-page splash) and splash/*.png (iOS launch screens).
The splash background (BG_SPLASH) MUST match SPLASH_BG in tools/build.mjs (manifest background_color, theme-color and the in-page splash all use it)."""
from PIL import Image
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BG_SPLASH = (17, 24, 39, 255)   # #111827  == SPLASH_BG in tools/build.mjs (iOS launch screens + the 'any' icons Android draws its splash from)
BG = (17, 24, 39, 255)          # #111827 — launcher icon background (maskable, apple-touch, favicon); the orange logo needs a dark ground
src = Image.open(os.path.join(ROOT, 'tools/pwa-src/logo.png')).convert('RGBA')
src = src.crop(src.split()[3].point(lambda a: 255 if a > 8 else 0).getbbox())   # trim empty margin

def canvas(w, h, logo_w=None, logo_h=None, cy=0.5, transparent=False):
    """the logo fitted into logo_w x logo_h, centred horizontally, centre at cy*h.
       transparent=False: on the solid splash colour, saved as opaque RGB (iOS launch images must be opaque).
       transparent=True : NO background at all, RGBA - for the manifest 'any' icons. Android draws its PWA splash from these on top of
                          manifest background_color, so a baked-in background shows up as a visible box."""
    c = Image.new('RGBA', (w, h), (0, 0, 0, 0) if transparent else BG_SPLASH)
    k = min((logo_w or w) / splash_src.width, (logo_h or h) / splash_src.height)
    lg = splash_src.resize((max(1, round(splash_src.width * k)), max(1, round(splash_src.height * k))), Image.LANCZOS)
    c.alpha_composite(lg, ((w - lg.width) // 2, round(h * cy - lg.height / 2)))
    return c if transparent else c.convert('RGB')

out = os.path.join(ROOT, 'shared/pwa')
os.makedirs(os.path.join(out, 'splash'), exist_ok=True)
# Two different pictures on purpose:
#   * HOME-SCREEN icon  = tools/pwa-src/app-icon.png  -> icon-maskable-*, apple-touch-icon, favicon (what the launcher draws)
#   * SPLASH / 'any'    = the full logo on the splash colour -> icon-192/512 (+ splash-logo.png, splash/*)
# (Android draws its splash from the manifest icons; launchers prefer the 'maskable' ones for the app icon.)
# home-screen icon artwork: tools/pwa-src/app-icon-art.png (finished rounded-square icon, transparent corners)
art = Image.open(os.path.join(ROOT, 'tools/pwa-src/app-icon-art.png')).convert('RGBA')
art = art.crop(art.split()[3].point(lambda a: 255 if a > 8 else 0).getbbox())
# splash artwork: tools/pwa-src/splash-logo.png (transparent) - used ONLY by splash-logo.png and splash/*.png
splash_src = Image.open(os.path.join(ROOT, 'tools/pwa-src/splash-logo.png')).convert('RGBA')
splash_src = splash_src.crop(splash_src.split()[3].point(lambda a: 255 if a > 8 else 0).getbbox())
def splash_icon(n, inner):
    """'any' icons: the transparent splash logo on the solid splash colour, fitted inside the central inner*n box."""
    c = Image.new('RGBA', (n, n), BG_SPLASH)
    k = n * inner / max(splash_src.width, splash_src.height)
    lg = splash_src.resize((max(1, round(splash_src.width * k)), max(1, round(splash_src.height * k))), Image.LANCZOS)
    c.alpha_composite(lg, ((n - lg.width) // 2, (n - lg.height) // 2))
    return c.convert('RGB')
def app_icon(n, inner):
    """opaque square in the brand colour (#f97316) with the icon artwork centred; inner = share of the side the artwork fills
       (0.80 = the maskable safe zone, so round / squircle masks never cut the text or logo)."""
    c = Image.new('RGBA', (n, n), BG)
    k = n * inner / max(art.width, art.height)
    lg = art.resize((max(1, round(art.width * k)), max(1, round(art.height * k))), Image.LANCZOS)
    c.alpha_composite(lg, ((n - lg.width) // 2, (n - lg.height) // 2))
    return c.convert('RGB')
for n in (192, 512):
    # ALL four launcher icons: opaque brand orange, logo inside the central 80% safe zone (its diagonal fits the 80% circle,
    # so round / squircle masks never clip it). They are NOT used for the splash any more (splash-logo.png + splash/*.png do that).
    splash_icon(n, .80).save(f'{out}/icon-{n}.png', optimize=True)       # 'any'      <- tools/pwa-src/splash-logo.png
    app_icon(n, .80).save(f'{out}/icon-maskable-{n}.png', optimize=True)  # 'maskable' <- tools/pwa-src/app-icon-art.png
app_icon(180, .84).save(f'{out}/apple-touch-icon.png', optimize=True)
app_icon(32, .9).save(f'{out}/favicon-32.png', optimize=True)
# in-app splash (src/partials/splash.html): transparent, the page supplies the background
k = 800 / splash_src.width
splash_src.resize((800, round(splash_src.height * k)), Image.LANCZOS).save(f'{out}/splash-logo.png', optimize=True)
# 'From MG - Tours' credit shown under the logo on the in-page splash
fm = Image.open(os.path.join(ROOT, 'tools/pwa-src/from-mg.png')).convert('RGBA')
fm.resize((420, round(fm.height * 420 / fm.width)), Image.LANCZOS).save(f'{out}/from-mg.png', optimize=True)

# iOS launch screens (apple-touch-startup-image). (css width, css height, pixel ratio) — keep in sync with IOS_SPLASH in tools/build.mjs
IOS = [(430,932,3),(393,852,3),(428,926,3),(390,844,3),(375,812,3),(414,896,3),(414,896,2),(414,736,3),(375,667,2),(320,568,2),
       (402,874,3),(440,956,3),(834,1194,2),(820,1180,2),(1024,1366,2),(810,1080,2),(744,1133,2)]
for w, h, r in IOS:
    W, H = w * r, h * r
    # same spot as the in-page splash: centred, a touch above the middle; ~62% of the screen width (phones) / 40% (tablets)
    frac = .62 if w < 600 else .40
    canvas(W, H, W * frac, H * .5, cy=.45).save(f'{out}/splash/{W}x{H}.png', optimize=True)
print('done')
